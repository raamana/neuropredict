
def summarize_misclassifications(misclf_stats):
    "Summary of most/least frequently mislcassified subjects for further analysis"


def visualize_metrics():
    "Distribution plots of various metrics"

    pass


def stat_comparison(clf_results):
    "Non-parametric statistical comparison of different feature sets"

    pass



if __name__ == '__main__':
    pass