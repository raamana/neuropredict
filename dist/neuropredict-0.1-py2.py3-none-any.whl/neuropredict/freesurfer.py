

def fsvolumes(path, subjid):
    """Returns a feature set of volumes found in aparc+aseg.stats"""




def fsthickness(path, subjid, fwhm=10):
    """
    Returns thickness feature set at a given fwhm.

    Assumes freesurfer was run with -qcache flag!

    """



if __name__ == '__main__':
    pass