
import rhst
data_loc = '/Users/Reddy/rotman/psy/test_MLdatasets/paths.txt'
out_dir  = '/Users/Reddy/rotman/psy/test_MLdatasets/results'

rhst.run(data_loc, out_dir, num_repetitions=10)
